module.exports = {
    HOST:'103.117.180.175',
    USER:'root',
    PASSWORD:'BGk3FVgKXR',
    DB:'sos_crm',
    PORT:'3306'
  };